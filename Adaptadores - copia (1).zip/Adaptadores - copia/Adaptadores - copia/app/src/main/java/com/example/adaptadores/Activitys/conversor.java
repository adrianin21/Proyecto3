package com.example.adaptadores.Activitys;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.adaptadores.R;

public class conversor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversor);
        getSupportActionBar().setTitle("Conversor");

        EditText txtEntrada,txtConversion;
        Button btnDolares,btnFarenheit,btnSoles,btnCentigrados,btnClear1;

        txtEntrada=(EditText)findViewById(R.id.txtEntrada);
        txtConversion=(EditText)findViewById(R.id.txtConversion);

        btnDolares=(Button)findViewById(R.id.btnDolares);
        btnFarenheit=(Button)findViewById(R.id.btnFarenheit);
        btnSoles=(Button)findViewById(R.id.btnSoles);
        btnCentigrados=(Button)findViewById(R.id.btnCentigrados);
        btnClear1=(Button)findViewById(R.id.btnClear1);


        btnFarenheit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double entrada1=Integer.parseInt(txtEntrada.getText().toString());
                double entrada2=(entrada1*(9/5))+32;

                txtConversion.setText(entrada2+"°K");
            }
        });
        btnCentigrados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double entrada1=Integer.parseInt(txtEntrada.getText().toString());
                double entrada2=(entrada1-32)*(5/9);

                txtConversion.setText(entrada2+"°C");
            }
        });
        btnSoles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double entrada1=Integer.parseInt(txtEntrada.getText().toString());
                double entrada2=entrada1*3.88;

                txtConversion.setText(entrada2+" soles");
            }
        });
        btnDolares.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double entrada1=Integer.parseInt(txtEntrada.getText().toString());
                double entrada2=entrada1/3.88;

                txtConversion.setText(entrada2+" dolares");
            }
        });

        btnClear1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtEntrada.setText("");
                txtConversion.setText("");
            }
        });
    }
}