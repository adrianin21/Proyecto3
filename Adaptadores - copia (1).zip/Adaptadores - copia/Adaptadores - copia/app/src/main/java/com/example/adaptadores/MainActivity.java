package com.example.adaptadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.adaptadores.Activitys.DestinosActivity;
import com.example.adaptadores.Activitys.UbicacionActivity;

public class MainActivity extends AppCompatActivity {

    Button menu,mapa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        menu=(Button)findViewById(R.id.btnMenu);
        mapa=(Button)findViewById(R.id.btnMaps);

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,MenuPrincipal.class);
                startActivity(intent);
            }
        });
        mapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, UbicacionActivity.class);
                startActivity(intent);
            }
        });
    }

}