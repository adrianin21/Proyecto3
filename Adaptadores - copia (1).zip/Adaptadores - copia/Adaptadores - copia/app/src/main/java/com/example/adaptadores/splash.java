package com.example.adaptadores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class splash extends AppCompatActivity {

    private static final long SPLASH_SCREEN_DELAY =3000;
    Animation topAnim,bottomAnim;
    ImageView ivLogoUac;
    TextView tvUni,tvLug;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        getSupportActionBar().setTitle("incio");
        topAnim= AnimationUtils.loadAnimation(this,R.anim.top_animacion);
        bottomAnim=AnimationUtils.loadAnimation(this,R.anim.boton_animacion);

        ivLogoUac=findViewById(R.id.ivLogoUac);
        tvUni=findViewById(R.id.tvUni);
        tvLug=findViewById(R.id.tvLug);

        ivLogoUac.setAnimation(topAnim);
        tvUni.setAnimation(bottomAnim);
        tvLug.setAnimation(bottomAnim);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(splash.this,MainActivity2.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN_DELAY);
    }

}