package com.example.adaptadores.Adaptadores;

import com.example.adaptadores.R;

import java.util.ArrayList;
import java.util.List;

public class RestaurantsItems {
    // declaro el arreglo
    private static final List<restaurantsItems> ITEMS = new ArrayList<restaurantsItems>();
    //contenido del arreglo
    static {
        addItem(new RestaurantsItems.restaurantsItems ("1","Restaurant del hotel Sonesta", R.drawable.gastrouno,"aventura"));
        addItem(new RestaurantsItems.restaurantsItems("2","Restaurant del Hotel Jw Marriott El Convento Cusco",R.drawable.gastrodos,"aventura"));
        addItem(new RestaurantsItems.restaurantsItems("3","Restaurant del Hotel Golden Inca", R.drawable.gastrotres,"aventura"));
        addItem(new RestaurantsItems.restaurantsItems("4","Restaurant del Hotel Casa Real", R.drawable.gastrocuatro,"aventura"));
        addItem(new RestaurantsItems.restaurantsItems("5","Restaurant del hotel Casa Andina", R.drawable.gastrocinco,"aventura"));
    }
    //metodo que contruye el arreglo , metodo principal
    static void addItem(RestaurantsItems.restaurantsItems item){
        ITEMS.add(item);
    }
    // metodo para agregar objetos
    public static ArrayList<RestaurantsItems.restaurantsItems> ArregloLista (){
        ArrayList<RestaurantsItems.restaurantsItems> d = new ArrayList<RestaurantsItems.restaurantsItems>();
        for(RestaurantsItems.restaurantsItems obj:ITEMS){
            d.add(obj);
        }
        return d;
    }
    // metodo para traer datos
    public static RestaurantsItems.restaurantsItems getRestaurantsItems(String id){
        for(RestaurantsItems.restaurantsItems obj:ITEMS){
            if (obj.id.equals(id)){
                return obj;
            }
        }
        return ITEMS.get(1); // busqueda título
    }
    // crear arreglo
    public static class restaurantsItems {

        private String id;
        private String titulo;
        private Integer imagen;
        private String tipoTurismo;

        public restaurantsItems(String id,String titulo,Integer imagen,String tipoTurismo){
            this.id = id;
            this.titulo = titulo;
            this.imagen = imagen;
            this.tipoTurismo = tipoTurismo;
        }
        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitulo() {
            return titulo;
        }

        public void setTitulo(String titulo) {
            this.titulo = titulo;
        }

        public Integer getImagen() {
            return imagen;
        }

        public void setImagen(Integer imagen) {
            this.imagen = imagen;
        }

        public String getTipoTurismo() {
            return tipoTurismo;
        }

        public void setTipoTurismo(String tipoTurismo) {
            this.tipoTurismo = tipoTurismo;
        }
    }
}
