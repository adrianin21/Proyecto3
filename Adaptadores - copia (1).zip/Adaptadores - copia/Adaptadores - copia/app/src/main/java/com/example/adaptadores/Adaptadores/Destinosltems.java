package com.example.adaptadores.Adaptadores;

import com.example.adaptadores.R;

import java.util.ArrayList;
import java.util.List;

public class Destinosltems {
    // declaro el arreglo
    private static final List<destinosItems> ITEMS = new ArrayList<destinosItems>();
    //contenido del arreglo
    static {
        addItem(new Destinosltems .destinosItems ("1","Iglesia de San Pedro (Andahuaylillas)", R.drawable.destinouno,"aventura"));
        addItem(new Destinosltems .destinosItems("2","chincheros",R.drawable.destinodos,"aventura"));
        addItem(new Destinosltems .destinosItems("3","salkantay", R.drawable.destinotres,"aventura"));
        addItem(new Destinosltems .destinosItems("4","salineras de maras", R.drawable.destinocuatro,"aventura"));
        addItem(new Destinosltems .destinosItems("5","montaña 7 colores", R.drawable.destinocinco,"aventura"));
    }
    //metodo que contruye el arreglo , metodo principal
    static void addItem(Destinosltems .destinosItems item){
        ITEMS.add(item);
    }
    // metodo para agregar objetos
    public static ArrayList<Destinosltems .destinosItems> ArregloLista (){
        ArrayList<Destinosltems .destinosItems> d = new ArrayList<Destinosltems .destinosItems>();
        for(Destinosltems .destinosItems obj:ITEMS){
            d.add(obj);
        }
        return d;
    }
    // metodo para traer datos
    public static Destinosltems .destinosItems getDestinosltems(String id){
        for(Destinosltems .destinosItems obj:ITEMS){
            if (obj.id.equals(id)){
                return obj;
            }
        }
        return ITEMS.get(1); // busqueda título
    }
    // crear arreglo
    public static class destinosItems {

        private String id;
        private String titulo;
        private Integer imagen;
        private String tipoTurismo;

        public destinosItems(String id,String titulo,Integer imagen,String tipoTurismo){
            this.id = id;
            this.titulo = titulo;
            this.imagen = imagen;
            this.tipoTurismo = tipoTurismo;
        }
        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitulo() {
            return titulo;
        }

        public void setTitulo(String titulo) {
            this.titulo = titulo;
        }

        public Integer getImagen() {
            return imagen;
        }

        public void setImagen(Integer imagen) {
            this.imagen = imagen;
        }

        public String getTipoTurismo() {
            return tipoTurismo;
        }

        public void setTipoTurismo(String tipoTurismo) {
            this.tipoTurismo = tipoTurismo;
        }
    }
}
