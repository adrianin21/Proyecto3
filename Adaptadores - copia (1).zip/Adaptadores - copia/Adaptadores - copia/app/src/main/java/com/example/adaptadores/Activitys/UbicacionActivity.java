package com.example.adaptadores.Activitys;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.adaptadores.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONObject;

public class UbicacionActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener  {

    private GoogleMap mMap;
    private Marker markerPrueba;
    private Boolean actualPos = true;
    private JSONObject jso;
    double longitudOri, latitudOri;
    private Button btn_hibrido, btn_normal, btn_satelital, btn_terreno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubicacion);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
//*****
        btn_hibrido = (Button) findViewById(R.id.btnHibrido);
        btn_normal = (Button) findViewById(R.id.btnNormal);
        btn_satelital = (Button) findViewById(R.id.btnSatelital);
        btn_terreno = (Button) findViewById(R.id.btnTerreno);
    }

    public void cambiarHibrido(View view) {
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
    }

    public void cambiarNormal(View view) {
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
    }

    public void cambiarSatelital(View view) {
        mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
    }

    public void cambiarTerreno(View view) {
        mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


        UiSettings uiSettings = mMap.getUiSettings();
        uiSettings.setZoomControlsEnabled(true);
        // Add a marker in Sydney and move the camera

        //HOTELES
        LatLng casandina=new LatLng(-13.519420147246421,-71.9745454791673);
        mMap.addMarker(new MarkerOptions().position(casandina).title("Hotel Casa Andino").snippet("")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.hotelmap)));

        LatLng sonesta=new LatLng(-13.52484826633696,-71.9729655062151);
        mMap.addMarker(new MarkerOptions().position(sonesta).title("Hotel sonesta").snippet("")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.hotelmap)));

        LatLng casareal=new LatLng(-13.522485694586408,-71.97248820440144);
        mMap.addMarker(new MarkerOptions().position(casareal).title("Hotel Casa Real").snippet("")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.hotelmap)));

        LatLng mariot=new LatLng(-13.51694487961636,-71.97595448023026);
        mMap.addMarker(new MarkerOptions().position(mariot).title("Hotel Mariott").snippet("")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.hotelmap)));

        LatLng goldeninca=new LatLng(-13.518458072260458,-71.96885742368235);
        mMap.addMarker(new MarkerOptions().position(goldeninca).title("Hotel Golden Inca").snippet("")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.hotelmap)));

        //DESTINOS TURISTICOS
        LatLng pisac=new LatLng(-13.4210472,-71.850496);
        mMap.addMarker(new MarkerOptions().position(pisac).title("Pisac").snippet("es un complejo arqueológico que está en el distrito homónimo de la provincia de Calca")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.ruinas)));

        LatLng ollanta=new LatLng(-13.255845,-72.2663165);
        mMap.addMarker(new MarkerOptions().position(ollanta).title("ollantaytambo").snippet("es uno de los principales centros arqueológicos del Cusco. Sus ruinas poseen andenes y construcciones increíbles")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.ruinas)));

        LatLng choque=new LatLng(-13.3938903,-72.868856);
        mMap.addMarker(new MarkerOptions().position(choque).title("Choquequirao").snippet("es considerada uno de los últimos bastiones de resistencia y refugio de los Incas, quienes por órdenes de Manco Inca")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.ruinas)));

        LatLng montana=new LatLng(-14.0360801,-71.251175);
        mMap.addMarker(new MarkerOptions().position(montana).title("La montaña de los 7 colores").snippet("es una de las nuevas y mejores atracciones del Perú. Ubicada a más de 100 kilómetros de la ciudad del Cusco")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.ruinas)));
        float zoolevel=20;
    }
    @Override
    public boolean onMarkerClick(@NonNull Marker marker) {
        if(marker.equals(markerPrueba)){

            String lat,lng;
            lat=Double.toString(marker.getPosition().latitude);
            lng=Double.toString(marker.getPosition().longitude);

            Toast.makeText(this,lat+','+lng,Toast.LENGTH_SHORT).show();
        }
        return false;
    }
}